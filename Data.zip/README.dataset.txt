# sign > 2024-04-28 10:48pm
https://universe.roboflow.com/1-jtkno/sign-3101e

Provided by a Roboflow user
License: CC BY 4.0

